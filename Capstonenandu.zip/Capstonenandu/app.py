from flask import Flask, render_template, request, redirect, flash
import mysql.connector

app = Flask(__name__, static_folder= "assets")
app.secret_key = 'your_secret_key'

# MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Iqlaas@123",
    database="flask_app"
)

# Home route - renders index.html
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/Appstore', endpoint='appstore_view')
def appstore():
    return render_template('appstore.html')

@app.route('/googleplay', endpoint='googleplay_view')
def googleplay():
    return render_template('googleplay.html')


@app.route('/ride')
def racing():
    return render_template('rideanalysis.html')

@app.route('/gps')
def routing():
    return render_template('gps.html')

@app.route('/smart')
def smart_feature():
    return render_template('smart.html')

# Route for login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get form data
        email = request.form['email']
        password = request.form['password']

        # Check if the user exists in the database
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()

        if user:
            # If user is found, redirect to the index page
            flash("Login successful!", "success")
            return redirect('/')
        else:
            # If user not found, show error message
            flash("Invalid email or password. Please try again.", "error")
            return redirect('/login')

    # If request method is GET, render the login page
    return render_template('login.html')


@app.route('/explore')
def explore():
    return render_template('bikes.html')


# Route for registration page
@app.route('/register', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords do not match. Please try again.", "error")
            return redirect('/register')

        cursor = db.cursor()
        cursor.execute("SELECT email FROM users WHERE email = %s", (email,))
        result = cursor.fetchone()

        if result:
            flash("Email already in use. Please try a different one or login.", "error")
            return redirect('/register')

        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, password))
        db.commit()
        flash("Signup successful! Please log in.", "success")
        return redirect('/login')

    return render_template('Registration.html')

if __name__ == '__main__':
    app.run(debug=True)
