// Sample Data for Yamaha Bikes
const bikes = [
    {
        name: "Yamaha R15 V3",
        price: 157000,
        engine: "155 cc",
        fuelCapacity: "11 Liters",
        mileage: "40 kmpl",
        colors: ["Blue", "Black", "Red"],
        image: "https://example.com/r15.jpg",
        media: [
            "https://example.com/r15-1.jpg",
            "https://example.com/r15-2.jpg"
        ]
    },
    {
        name: "Yamaha FZ FI",
        price: 102000,
        engine: "149 cc",
        fuelCapacity: "12.8 Liters",
        mileage: "45 kmpl",
        colors: ["Blue", "Grey", "Black"],
        image: "https://example.com/fzfi.jpg",
        media: [
            "https://example.com/fzfi-1.jpg",
            "https://example.com/fzfi-2.jpg"
        ]
    },
    // Add more bikes
];

// Function to load bikes into the homepage
function loadBikes() {
    const bikeList = document.getElementById('bikeList');
    bikeList.innerHTML = '';

    bikes.forEach((bike, index) => {
        const bikeCard = `
            <div class="col-md-4">
                <div class="card">
                    <img src="${bike.image}" class="card-img-top" alt="${bike.name}">
                    <div class="card-body">
                        <h5 class="card-title">${bike.name}</h5>
                        <p class="card-text">Price: ₹${bike.price}</p>
                        <button class="btn btn-primary" onclick="showBikeDetails(${index})" data-bs-toggle="modal" data-bs-target="#bikeModal">View Details</button>
                    </div>
                </div>
            </div>`;
        bikeList.innerHTML += bikeCard;
    });
}

// Function to show details of a selected bike
function showBikeDetails(index) {
    const bike = bikes[index];
    document.getElementById('bikeName').textContent = bike.name;
    document.getElementById('bikePrice').textContent = `₹${bike.price}`;
    document.getElementById('bikeEngine').textContent = bike.engine;
    document.getElementById('bikeFuel').textContent = bike.fuelCapacity;
    document.getElementById('bikeMileage').textContent = bike.mileage;
    document.getElementById('bikeColors').textContent = bike.colors.join(', ');

    // Display media gallery
    const mediaDiv = document.getElementById('bikeMedia');
    mediaDiv.innerHTML = '';
    bike.media.forEach((mediaUrl) => {
        mediaDiv.innerHTML += `<img src="${mediaUrl}" class="img-fluid" alt="${bike.name} image">`;
    });
}

// Function to handle bike search
function searchBikes() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const filteredBikes = bikes.filter(bike => bike.name.toLowerCase().includes(searchInput));
    displayBikes(filteredBikes);
}

// Function to handle price range filtering
function filterBikes() {
    const priceRange = document.getElementById('priceRange').value;
    document.getElementById('priceDisplay').textContent = `Price: ₹${priceRange}`;
    const filteredBikes = bikes.filter(bike => bike.price <= priceRange);
    displayBikes(filteredBikes);
}

// Function to display bikes based on filters
function displayBikes(filteredBikes) {
    const bikeList = document.getElementById('bikeList');
    bikeList.innerHTML = '';
    
    filteredBikes.forEach((bike, index) => {
        const bikeCard = `
            <div class="col-md-4">
                <div class="card">
                    <img src="${bike.image}" class="card-img-top" alt="${bike.name}">
                    <div class="card-body">
                        <h5 class="card-title">${bike.name}</h5>
                        <p class="card-text">Price: ₹${bike.price}</p>
                        <button class="btn btn-primary" onclick="showBikeDetails(${index})" data-bs-toggle="modal" data-bs-target="#bikeModal">View Details</button>
                    </div>
                </div>
            </div>`;
        bikeList.innerHTML += bikeCard;
    });
}

// Initial Load
document.addEventListener('DOMContentLoaded', () => {
    loadBikes();
});
